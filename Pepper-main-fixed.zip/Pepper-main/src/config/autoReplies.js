// Auto replies: the bot answers by itself when a message contains certain words (no command needed).
// To add another one, copy a block and change the pattern and the text.
export const AUTO_REPLIES = [
    {
        name: 'media-perms',

        // Works ANYWHERE in a message. Matches "image perm", "img perm", "media perm" (also perms / permission),
        // and the other way round: "perms for images", "permission to send media" ...
        pattern: new RegExp(
            '\\b(?:image|img|media|pic|picture|photo)s?\\s*\\/?\\s*(?:perm|perms|permission|permissions)\\b'
            + '|\\b(?:perm|perms|permission|permissions)\\s+(?:for|to|of|on)?\\s*(?:send\\s+|sending\\s+|post\\s+|posting\\s+)?(?:image|images|img|imgs|media|pic|pics|picture|pictures|photo|photos)\\b',
            'i',
        ),

        // Wait this long before answering the same person / the same channel again (seconds)
        userCooldown: 60,
        channelCooldown: 20,

        // Sent as a plain message right under the box so people can hold it and copy it.
        // (turned off: no separate link message. Put a link here to send it again under the box.)
        copyText: '',

        // Black-bordered box (no emojis)
        embed: {
            color: 0x010101,
            title: 'Image Perms (do any one)',
            description: [
                '• **Put This** `https://discord.gg/4YzqDyR5wp` **In Your Status** (you have to be online)',
                '• **Boost the server** and enjoy the server perks',
                '• **Reach level 10**',
            ].join('\n'),
        },
    },
];

// Channels (by ID) where auto replies stay quiet.
export const AUTO_REPLY_IGNORED_CHANNEL_IDS = [];
