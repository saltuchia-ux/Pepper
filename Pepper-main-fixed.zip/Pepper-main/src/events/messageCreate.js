import { Events } from 'discord.js';
import { logger } from '../utils/logger.js';

import {
  getLevelingConfig,
  getUserLevelData
} from '../services/leveling/leveling.js';

import { addXp } from '../services/leveling/xpSystem.js';
import { checkRateLimit } from '../utils/rateLimiter.js';
import { executePrefixCommand } from '../utils/messageAdapter.js';
import { findCommandByTrigger } from '../utils/commandSettingsEngine.js';
import { FEATURES } from '../config/features.js';

import {
  getCountingGameConfig,
  saveCountingGameConfig,
  isValidCountingMessage,
  recordCorrectCount,
  refreshCountingRules
} from '../services/countingGameService.js';

const MESSAGE_XP_RATE_LIMIT_ATTEMPTS = 12;
const MESSAGE_XP_RATE_LIMIT_WINDOW_MS = 10000;

export default {
  name: Events.MessageCreate,

  async execute(message, client) {
    try {
      if (message.author.bot || !message.guild) {
        return;
      }

      logger.debug(
        `Message received from ${message.author.tag}: ${message.content}`
      );

      // ==========================================
      // PREFIX COMMANDS
      // ==========================================

      await handlePrefixCommand(
        message,
        client
      );

      // ==========================================
      // COUNTING GAME
      // ==========================================

      const countingProcessed =
        await handleCountingGame(
          message,
          client
        );

      if (countingProcessed) {
        return;
      }

      // ==========================================
      // XP / LEVELING
      // ==========================================

      if (FEATURES.leveling) {
        await handleLeveling(
          message,
          client
        );
      }

    } catch (error) {
      logger.error(
        'Error in messageCreate event:',
        error
      );
    }
  }
};


// ==========================================
// PREFIX COMMAND HANDLER
// ==========================================

async function handlePrefixCommand(
  message,
  client
) {
  try {
    const prefix = '.';

    if (
      !message.content.startsWith(prefix)
    ) {
      return;
    }

    // Words are split by spaces, but "John Smith" in quotes stays one word
    const parts =
      (message.content.slice(prefix.length).trim().match(/"[^"]*"|\S+/g) || [])
        .map((word) =>
          word.length > 1 && word.startsWith('"') && word.endsWith('"')
            ? word.slice(1, -1)
            : word
        );

    const commandName =
      parts.shift()?.toLowerCase();

    if (!commandName) {
      return;
    }

    // which command does this word run?  (settings: src/config/commandSettings.js)
    const command = await findCommandByTrigger(client, commandName, message.guild?.id);

    if (!command) {
      return;
    }

    console.log(
      `PREFIX COMMAND FOUND: ${commandName}`
    );

    await executePrefixCommand(
      command,
      message,
      parts,
      client,
      prefix,
      {
        prefix: '.'
      }
    );

  } catch (error) {
    console.error(
      'PREFIX COMMAND ERROR:',
      error
    );
  }
}


// ==========================================
// COUNTING GAME
// ==========================================

async function handleCountingGame(
  message,
  client
) {
  try {
    const config =
      await getCountingGameConfig(
        client,
        message.guild.id
      );

    if (
      !config?.enabled ||
      !config.channelId
    ) {
      return false;
    }

    if (
      message.channel.id !==
      config.channelId
    ) {
      return false;
    }

    const content =
      message.content.trim();

    // Allow prefix commands (the rules still go back to the bottom)
    if (content.startsWith('.')) {
      await refreshCountingRules(
        message.channel,
        config
      );

      return false;
    }

    // Non-number messages: ignored, but the rules still go back to the bottom
    if (
      !isValidCountingMessage(content)
    ) {
      await refreshCountingRules(
        message.channel,
        config
      );

      return true;
    }

    const number =
      Number(content);

    const expected =
      config.nextNumber || 1;

    // ==========================================
    // SAME PERSON TWICE
    // ==========================================

    if (
      config.lastUserId ===
      message.author.id
    ) {
      const resetConfig = {
        ...config,
        nextNumber: 1,
        lastUserId: null
      };

      await saveCountingGameConfig(
        client,
        message.guild.id,
        resetConfig
      );

      await message
        .react('❌')
        .catch(() => {});

      await message.channel.send({
        embeds: [
          {
            color: 0xED4245,

            description:
              `💥 **You can't count two numbers in a row!**\n` +
              `The next number is **1**.`
          }
        ]
      }).catch(() => {});

      await refreshCountingRules(
        message.channel,
        resetConfig
      );

      return true;
    }

    // ==========================================
    // WRONG NUMBER
    // ==========================================

    if (
      number !== expected
    ) {
      const resetConfig = {
        ...config,
        nextNumber: 1,
        lastUserId: null
      };

      await saveCountingGameConfig(
        client,
        message.guild.id,
        resetConfig
      );

      await message
        .react('❌')
        .catch(() => {});

      await message.channel.send({
        embeds: [
          {
            color: 0xED4245,

            title: '💥 Wrong! Chain Broken',

            description:
              `The next number was **${expected}**.`
          }
        ]
      }).catch(() => {});

      await refreshCountingRules(
        message.channel,
        resetConfig
      );

      return true;
    }

    // ==========================================
    // CORRECT NUMBER
    // ==========================================

    const updatedConfig =
      await recordCorrectCount(
        client,
        message.guild.id,
        message.author.id,
        number
      );

    await message
      .react('✅')
      .catch(() => {});

    await refreshCountingRules(
      message.channel,
      updatedConfig
    );

    return true;

  } catch (error) {
    logger.error(
      'Error handling counting game:',
      error
    );

    return false;
  }
}


// ==========================================
// LEVELING
// ==========================================

async function handleLeveling(
  message,
  client
) {
  try {
    const rateLimitKey =
      `xp-event:${message.guild.id}:${message.author.id}`;

    const canProcess =
      await checkRateLimit(
        rateLimitKey,
        MESSAGE_XP_RATE_LIMIT_ATTEMPTS,
        MESSAGE_XP_RATE_LIMIT_WINDOW_MS
      );

    if (!canProcess) {
      return;
    }

    const levelingConfig =
      await getLevelingConfig(
        client,
        message.guild.id
      );

    if (
      !levelingConfig?.enabled
    ) {
      return;
    }

    if (
      levelingConfig.ignoredChannels?.includes(
        message.channel.id
      )
    ) {
      return;
    }

    if (
      levelingConfig.ignoredRoles?.length > 0
    ) {
      const member =
        await message.guild.members
          .fetch(
            message.author.id
          )
          .catch(() => null);

      if (
        member &&
        member.roles.cache.some(
          role =>
            levelingConfig.ignoredRoles.includes(
              role.id
            )
        )
      ) {
        return;
      }
    }

    if (
      levelingConfig.blacklistedUsers?.includes(
        message.author.id
      )
    ) {
      return;
    }

    if (
      !message.content ||
      message.content.trim().length === 0
    ) {
      return;
    }

    const userData =
      await getUserLevelData(
        client,
        message.guild.id,
        message.author.id
      );

    const cooldownTime =
      levelingConfig.xpCooldown || 60;

    const now = Date.now();

    const timeSinceLastMessage =
      now -
      (userData.lastMessage || 0);

    if (
      timeSinceLastMessage <
      cooldownTime * 1000
    ) {
      return;
    }

    // XP for this message: random between the min and max set in the leveling settings
    const xpMin = levelingConfig.xpRange?.min ?? levelingConfig.xpPerMessage?.min ?? 15;
    const xpMax = levelingConfig.xpRange?.max ?? levelingConfig.xpPerMessage?.max ?? 25;
    const low = Math.max(1, Math.min(xpMin, xpMax));
    const high = Math.max(low, xpMax);
    const xpToAdd = Math.max(
      1,
      Math.round((Math.floor(Math.random() * (high - low + 1)) + low) * (levelingConfig.xpMultiplier || 1))
    );

    const levelMember =
      message.member ??
      await message.guild.members
        .fetch(message.author.id)
        .catch(() => null);

    if (!levelMember) {
      return;
    }

    // addXp(client, guild, member, xp) - it used to be called with the IDs and the message,
    // which made it fail on every message ("xpSystem.addXp failed")
    await addXp(
      client,
      message.guild,
      levelMember,
      xpToAdd
    );

  } catch (error) {
    logger.error(
      'Error handling leveling:',
      error
    );
  }
}
